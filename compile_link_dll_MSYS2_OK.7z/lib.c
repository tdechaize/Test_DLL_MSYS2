int func(int A) {
    return A*2;
}
